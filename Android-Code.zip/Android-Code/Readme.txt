---------------------------

    *Smart Attendance*
      Version Details

---------------------------


V 0.1 :-
What's New ⏺
1) Register Activity [Add]
2) Login Activity [Add]
3) Attendance Sheet Activity [Add]
4) App Icon [Change]
5) Login Account [Add]
6) Firebase Services [Add]

-------------------------

V 0.2 :- 
What's New ⏺
1) Material Design [Add]
2) Admin Permission For Register Account [Add]
3) Login Activity Design [Change]
4) Register Activity Design [Change]
5) Logout Button [Add]

---------------------------

V 0.3 :-
What's New ⏺
1) Guildline [Add]
2) Layout change from Linear to Constraint [Change]
3) Quick Fix for below 5" inch screen phones [Fix]
4) Action Bar removed at Login page [Remove]

---------------------------

V 0.4 :-
What's New ⏺
1) Firebase Database [Add]
2) Firebase Storage [Add]

---------------------------

V 0.5 :-
What's New ⏺
1) File Retrieve Code [Add]

---------------------------

V 0.6 :-
What's New ⏺
1) Quick Fix - Firebase Storage [Fix]
2) Minor Changes [Change]

---------------------------